package NewProcess.Prep;

public class FilePrepper_columnPusher {

    String folder;

    public FilePrepper_columnPusher(String folder) {
        this.folder = folder;
    }



}
